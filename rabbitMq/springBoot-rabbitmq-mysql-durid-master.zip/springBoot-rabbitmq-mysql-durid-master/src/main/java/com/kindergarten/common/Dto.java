package com.kindergarten.common;

/**
 * @Date Created on 2017/7/14.
 * @Author SongJiuHua.
 * @description
 */
public interface Dto {

    public Long getId();
}
