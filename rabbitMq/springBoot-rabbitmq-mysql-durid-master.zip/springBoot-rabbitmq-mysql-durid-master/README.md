使用框架：  
Spring：SpringBoot  
DB：MySQL  
AMQP：RabbitMQ  
ORM：MyBatis  
Monitor：Druid  

rabbitmq服务地址：http://localhost:15672/  
rabbitmq用户名/密码：guest/guest  
 

druid监控地址：http://localhost:8080/druid/login.html  
druid用户名/密码：druid/druid 
